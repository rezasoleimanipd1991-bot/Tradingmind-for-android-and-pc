---
name: Artifact build environment
description: The required environment contract for manually validating the TraderMind Vite artifact.
---

Manual production builds of the TraderMind web artifact must provide the same `PORT` and `BASE_PATH` values that the managed artifact workflow injects. Without them, Vite intentionally fails while loading its configuration; this is an environment validation failure, not an application compile failure.

A byte-identical artifact source tree may still be unrunnable if the workspace-root manifests or dependency links are missing. Check that the root `package.json`, `pnpm-workspace.yaml`, and shared TypeScript config match the artifact's workspace before treating missing packages or TS config resolution as source-code defects.

**Why:** The artifact config requires both values to keep preview routing and service binding explicit, and PNPM workspace links depend on root manifests. A copied app directory alone may not include either part of the runtime contract.

**How to apply:** Before validation, confirm workspace manifests and links are present. When building outside the workflow, pass the target port and artifact base path explicitly, then restart the managed web workflow and inspect its logs.