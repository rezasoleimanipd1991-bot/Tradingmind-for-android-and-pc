import{m as c}from"./index-aifUrVXu.js";const o=[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],m=c("clock",o);export{m as C};
