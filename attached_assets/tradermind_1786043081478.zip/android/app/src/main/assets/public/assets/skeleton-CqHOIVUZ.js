import{j as s,M as a}from"./index-aifUrVXu.js";function t({className:e,...r}){return s.jsx("div",{className:a("animate-pulse rounded-md bg-primary/10",e),...r})}export{t as S};
